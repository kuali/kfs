insert into END_TYP_T  (TYP_CD, TYP_DESC, TYP_INC_RESTR_CD, TYP_PRIN_RESTR_CD, TYP_CSH_SWEEP_MDL_ID, TYP_INC_ACI_MDL_ID, TYP_PRIN_ACI_MDL_ID, ROW_ACTV_IND, OBJ_ID) values 
('011', 'Quasi Endowment-Budget', 'OP', 'OP', '1', null, '1', 'Y',UUID()),
('013', 'Quasi Endowment-Undecided', 'OP', 'OP', '1', null, '1', 'Y',UUID()),
('017', 'Permanent Endowment Funds - IUF', 'OP', 'PRF', '1', null, '1', 'Y',UUID()),
('032', 'Discretionary Accounts - Unrestricted IU', 'TRU', 'TRU', '1', null, null, 'Y',UUID()),
('037', 'Permanent Endowment - IU', 'TRU', 'PRU', '1', null, '1', 'Y',UUID()),
('038', 'Expendable Endowment (& income) - IU', 'TRU', 'TRU', '1', null, '1', 'Y',UUID()),
('046', 'Gift Annuities Held for Expendable Endowments (& income) - IU (custodial)', 'TRU', 'TRU', '1', null, '1', 'Y',UUID());
