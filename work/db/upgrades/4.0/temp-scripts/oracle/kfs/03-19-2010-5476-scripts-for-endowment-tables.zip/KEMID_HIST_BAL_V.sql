create view END_KEMID_HIST_BAL_V as
select
AUX1.kemid as KEMID,
AUX1.ME_DT_ID as ME_DT_ID,
AUX2.INCOME_AT_MARKET as INC_AT_MARKET,
AUX2.PRINCIPAL_AT_MARKET as PRIN_AT_MARKET,
AUX2.TOTAL_MARKET_VAL as TOTAL_MARKET_VAL,
AUX1.ANNUAL_INCOME as ANN_EST_INC,
AUX1.FY_REM_EST_INC as FY_REM_EST_INC,
AUX1.NEXT_FY_EST_INC as NEXT_FY_EST_INC
from ( select kemid, ME_DT_ID, sum(HLDG_ANNL_INC_EST) as ANNUAL_INCOME, sum(HLDG_FY_REM_EST_INC) as FY_REM_EST_INC, sum(HLDG_NEXT_FY_EST_INC) as NEXT_FY_EST_INC from END_HLDG_HIST_T group by kemid, ME_DT_ID ) AUX1,

(
   select
   TEMP1.*,
   TEMP2.INCOME_AT_MARKET,
   (INCOME_AT_MARKET + PRINCIPAL_AT_MARKET) as TOTAL_MARKET_VAL
   from
   (
      select
      A.kemid,A.ME_DT_ID, (HIST_PRIN_CSH + TOTAL_PRIN_MARKET_VAL) as PRINCIPAL_AT_MARKET
      from END_HIST_CSH_T A
      inner join
      (
         select
         E.kemid, E.ME_DT_ID, sum(hldg_mval) as TOTAL_PRIN_MARKET_VAL
         from END_HLDG_HIST_T E
         where E.hldg_IP_IND = 'P'
         group by E.kemid, E.ME_DT_ID
      )
      B on B.kemid = A.kemid and B.ME_DT_ID = A.ME_DT_ID
   )
   TEMP1
   inner join
   (
      select
      A.KEMID,A.ME_DT_ID, (HIST_INC_CSH + TOTAL_INC_MARKET_VAL) as INCOME_AT_MARKET
      from END_HIST_CSH_T A
      inner join
      (
         select
         E.kemid,E.ME_DT_ID, sum(hldg_mval) as TOTAL_INC_MARKET_VAL
         from END_HLDG_HIST_T E
         where E.hldg_IP_IND = 'I'
         group by E.kemid, E.ME_DT_ID
      )
      B on B.kemid = A.kemid and B.ME_DT_ID = A.ME_DT_ID
   )
   TEMP2 on TEMP1.kemid = TEMP2.kemid and TEMP1.ME_DT_ID = TEMP2.ME_DT_ID
)
AUX2
where aux1.kemid = aux2.kemid and aux1.ME_DT_ID = aux2.ME_DT_ID
