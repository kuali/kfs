insert into END_CLOSE_CD_T (CLOSE_CD, CLOSE_DESC, ROW_ACTV_IND, OBJ_ID) values 
('E', 'Expended', 'Y',UUID()),
('F', 'New Fund', 'Y',UUID()),
('I', 'Transferred to IU', 'Y',UUID()),
('M', 'Merged', 'Y',UUID()),
('N', 'Not Funded', 'Y',UUID()),
('O', 'Transferred to Outside Organization', 'Y',UUID()),
('P', 'Opened in Error', 'Y',UUID()),
('R', 'Refunded to Donor', 'Y',UUID()),
('T', 'Terminated', 'Y',UUID()),
('U', 'New Unit', 'Y',UUID());
