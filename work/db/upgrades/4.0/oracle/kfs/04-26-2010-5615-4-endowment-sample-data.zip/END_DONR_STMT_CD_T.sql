insert into END_DONR_STMT_CD_T columns (DONR_STMT_CD, DONR_STMT_DESC, ROW_ACTV_IND, OBJ_ID) values ('T', 'Terminated', 'y',sys_guid());
insert into END_DONR_STMT_CD_T columns (DONR_STMT_CD, DONR_STMT_DESC, ROW_ACTV_IND, OBJ_ID) values ('Q', 'Qualifies', 'y',sys_guid());
insert into END_DONR_STMT_CD_T columns (DONR_STMT_CD, DONR_STMT_DESC, ROW_ACTV_IND, OBJ_ID) values ('N', 'None', 'y',sys_guid());
insert into END_DONR_STMT_CD_T columns (DONR_STMT_CD, DONR_STMT_DESC, ROW_ACTV_IND, OBJ_ID) values ('M', 'Mid-Level', 'y',sys_guid());
insert into END_DONR_STMT_CD_T columns (DONR_STMT_CD, DONR_STMT_DESC, ROW_ACTV_IND, OBJ_ID) values ('MID', 'Mid-Level - DR', 'y',sys_guid());
insert into END_DONR_STMT_CD_T columns (DONR_STMT_CD, DONR_STMT_DESC, ROW_ACTV_IND, OBJ_ID) values ('S', 'Standard', 'y',sys_guid());
insert into END_DONR_STMT_CD_T columns (DONR_STMT_CD, DONR_STMT_DESC, ROW_ACTV_IND, OBJ_ID) values ('ST', 'Standard', 'y',sys_guid());
insert into END_DONR_STMT_CD_T columns (DONR_STMT_CD, DONR_STMT_DESC, ROW_ACTV_IND, OBJ_ID) values ('STD', 'Standard - DR', 'y',sys_guid());
insert into END_DONR_STMT_CD_T columns (DONR_STMT_CD, DONR_STMT_DESC, ROW_ACTV_IND, OBJ_ID) values ('TER', 'Terminated - DR', 'y',sys_guid());
