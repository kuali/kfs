
    create table END_ACRL_MTHD_T(
       SEC_ACRL_MTHD VARCHAR(1) not null primary key,
       SEC_ACRL_MTHD_DESC VARCHAR(150) not null,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null unique
    );
    
    
    create table END_AGRMNT_SPCL_INSTRC_CD_T(
       AGRMNT_SPCL_INSTRC_CD VARCHAR(3) not null primary key,
       AGRMNT_SPCL_INSTRC_DESC VARCHAR(75) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null
    );
    
    
    create table END_AGRMNT_STAT_CD_T(
       AGRMNT_STAT_CD VARCHAR(4) not null primary key,
       AGRMNT_STAT_DESC VARCHAR(75) not null,
       AGRMNT_DFLT_TRAN_RESTR VARCHAR(5) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null
    );

    alter table END_AGRMNT_STAT_CD_T  
        add constraint AGRMNT_DFLT_TRAN_RESTR 
        foreign key (AGRMNT_DFLT_TRAN_RESTR) 
        references END_TRAN_RESTR_CD_T(TRAN_RESTR_CD);
        

    create table END_AGRMNT_TYP_CD_T(
       AGRMNT_TYP_CD VARCHAR(3) not null primary key,
       AGRMNT_TYP_CD_DESC VARCHAR(75) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null
    );       
     
        
   create table END_AUTO_CSH_INVEST_MDL_T(
       ACI_MDL_ID DECIMAL(9) not null primary key,
       ACI_MDL_NM VARCHAR(100) not null,
       ACI_HLDG_IP_IND VARCHAR(1) not null,
       ACI_POOL1_SEC_ID VARCHAR(9) not null,
       ACI_POOL1_PCT DECIMAL(5,4) default '1.0000' not null,
       ACI_POOL2_SEC_ID VARCHAR(9),
       ACI_POOL2_PCT DECIMAL(5,4) default '0.0000',
       ACI_POOL3_SEC_ID VARCHAR(9),
       ACI_POOL3_REGIS_CD VARCHAR(4),
       ACI_POOL3_PCT DECIMAL(5,4) default '0.0000',
       ACI_POOL4_SEC_ID VARCHAR(9),
       ACI_POOL4_PCT DECIMAL(5,4) default '0.0000',
       ACI_FREQ VARCHAR(4) not null,
       ACI_MDL_DT DATE not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       ACI_POOL1_REGIS_CD VARCHAR(4) not null,
       ACI_POOL2_REGIS_CD VARCHAR(4),
       ACI_POOL4_REGIS_CD VARCHAR(4)
    );

    alter table END_AUTO_CSH_INVEST_MDL_T  
        add constraint ACI_HLDG_IP_IND 
        foreign key (ACI_HLDG_IP_IND) 
        references END_IP_IND_T(IP_IND_CD);
    alter table END_AUTO_CSH_INVEST_MDL_T  
        add constraint ACI_POOLED1_SECURITY_ID 
        foreign key (ACI_POOL1_SEC_ID) 
        references END_POOL_FND_CTRL_T(POOL_SEC_ID);
    alter table END_AUTO_CSH_INVEST_MDL_T  
        add constraint ACI_POOLED3_SECURITY_ID 
        foreign key (ACI_POOL3_SEC_ID) 
        references END_POOL_FND_CTRL_T(POOL_SEC_ID);
    alter table END_AUTO_CSH_INVEST_MDL_T  
        add constraint ACI_POOLED4_SECURITY_ID 
        foreign key (ACI_POOL4_SEC_ID) 
        references END_POOL_FND_CTRL_T(POOL_SEC_ID);
    alter table END_AUTO_CSH_INVEST_MDL_T  
        add constraint ACI_POOLED2_SECURITY_ID 
        foreign key (ACI_POOL2_SEC_ID) 
        references END_POOL_FND_CTRL_T(POOL_SEC_ID);
    alter table END_AUTO_CSH_INVEST_MDL_T  
        add constraint ACI_POOL1_REGIS_CD 
        foreign key (ACI_POOL1_REGIS_CD) 
        references END_REGIS_CD_T(REGIS_CD);
    alter table END_AUTO_CSH_INVEST_MDL_T  
        add constraint ACI_POOL2_REGIS_CD 
        foreign key (ACI_POOL2_REGIS_CD) 
        references KULENDOW.END_REGIS_CD_T(REGIS_CD);
    alter table END_AUTO_CSH_INVEST_MDL_T  
        add constraint ACI_POOL3_REGIS_CD 
        foreign key (ACI_POOL3_REGIS_CD) 
        references END_REGIS_CD_T(REGIS_CD);
    alter table END_AUTO_CSH_INVEST_MDL_T  
        add constraint ACI_POOL4_REGIS_CD 
        foreign key (ACI_POOL4_REGIS_CD) 
        references END_REGIS_CD_T(REGIS_CD);
        

    create table END_AVAIL_CSH_T(
        KEMID VARCHAR(10) not null primary key,
       AVAIL_INC_CSH DECIMAL(19,2) default '0.00' not null,
       AVAIL_PRIN_CSH DECIMAL(19,2) default '0.00' not null,
       AVAIL_TOT_CSH DECIMAL(19,2) default '0.00' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null
    );

    alter table END_AVAIL_CSH_T  
        add constraint AVAIL_CSH_KEMID_REF1 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);  


    create table END_CAE_TYP_CD_T(
       CAE_TYP_CD VARCHAR(1) not null primary key,
       CAE_TYP_DESC VARCHAR(36),
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null unique
    ); 
            
        
    create table END_CAE_CD_T(
       CAE_CD VARCHAR(1) not null primary key,
       CAE_DESC VARCHAR(75) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       CAE_TYP_CD VARCHAR(1) not null
    );

    alter table END_CAE_CD_T  
        add constraint CAE_TYP_CD_REF1 
        foreign key (CAE_TYP_CD) 
        references END_CAE_TYP_CD_T(CAE_TYP_CD); 


    create table END_CLOSE_CD_T(
       CLOSE_CD VARCHAR(3) not null primary key,
       CLOSE_DESC VARCHAR(75) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null
    );     
    

    create table END_CLS_CD_T(
       SEC_CLS_CD VARCHAR(3) not null primary key,
       SEC_CLS_CD_DESC VARCHAR(150),
       SEC_RPT_GRP VARCHAR(5) not null,
       SEC_ACRL_MTHD VARCHAR(1) not null,
       SEC_ETRAN_CD VARCHAR(9) not null,
       SEC_INC_ETRAN_POST_CD VARCHAR(9) not null,
       TAX_LOT_IND VARCHAR(1) default 'N',
       CLS_CD_TYP VARCHAR(1) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y',
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       VLTN_MTHD VARCHAR(1)
    );

    alter table END_CLS_CD_T  
        add constraint SECURITY_ACCRUAL_METHOD 
        foreign key (SEC_ACRL_MTHD) 
        references END_ACRL_MTHD_T(SEC_ACRL_MTHD);
    alter table END_CLS_CD_T  
        add constraint CLASS_CODE_TYPE 
        foreign key (CLS_CD_TYP) 
        references END_CLS_CD_TYP_T(CLS_CD_TYP);
    alter table END_CLS_CD_T  
        add constraint SEC_ETRAN_CD_REF1 
        foreign key (SEC_ETRAN_CD) 
        references END_ETRAN_CD_T(ETRAN_CD);
    alter table END_CLS_CD_T  
        add constraint SEC_INC_ETRAN_POST_CD_REF1 
        foreign key (SEC_INC_ETRAN_POST_CD) 
        references END_ETRAN_CD_T(ETRAN_CD);
    alter table END_CLS_CD_T  
        add constraint SECURITY_REPORTING_GROUP 
        foreign key (SEC_RPT_GRP) 
        references END_SEC_RPT_GRP_T(SEC_RPT_GRP);
    alter table END_CLS_CD_T  
        add constraint VLTN_MTHD_REF1 
        foreign key (VLTN_MTHD) 
        references END_SEC_VLTN_MTHD_T(VLTN_MTHD);
    
    
    create table END_CLS_CD_TYP_T(
       CLS_CD_TYP VARCHAR(1) not null primary key,
       CLS_CD_TYP_DESC VARCHAR(150),
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null unique
    );
    
    
    create table END_CMB_GRP_T(
       CMB_GRP_ID VARCHAR(5) not null primary key,
       CMB_GRP_DESC VARCHAR(75) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null
    );
    

    create table END_CRNT_CSH_T(
       KEMID VARCHAR(10) not null primary key,
       CRNT_INC_CSH DECIMAL(19,2) default '0.00' not null,
       CRNT_PRIN_CSH DECIMAL(19,2) default '0.00' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null
    );

    alter table END_CRNT_CSH_T  
        add constraint CRNT_CSH_KEMID_REF1 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);
        
        
    create table END_CRNT_TAX_LOT_BAL_T(
       KEMID VARCHAR(10) not null,
       SEC_ID VARCHAR(9) not null,
       REGIS_CD VARCHAR(4) not null,
       HLDG_LOT_NBR DECIMAL(4) default '1' not null,
       HLDG_IP_IND VARCHAR(1) not null,
       HLDG_UNITS DECIMAL(16,4) default '0.0000' not null,
       HLDG_COST DECIMAL(19,2) default '0.00' not null,
       HLDG_ANNL_INC_EST DECIMAL(19,2) default '0.00' not null,
       HLDG_FY_REM_EST_INC DECIMAL(19,2) default '0.00' not null,
       HLDG_NEXT_FY_EST_INC DECIMAL(19,2) default '0.00' not null,
       SEC_UNIT_VAL DECIMAL(19,5) not null,
       HLDG_ACQD_DT DATE not null,
       HLDG_PRIOR_ACRD_INC DECIMAL(19,2) default '0' not null,
       HLDG_ACRD_INC_DUE DECIMAL(19,5) default '0' not null,
       HLDG_FRGN_TAX_WITH DECIMAL(19,5) not null,
       LAST_TRAN_DT DATE not null,
       HLDG_MVAL DECIMAL(19,2) not null,
       OBJ_ID VARCHAR(36) not null,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (KEMID,SEC_ID,REGIS_CD,HLDG_LOT_NBR,HLDG_IP_IND)
    );

    alter table END_CRNT_TAX_LOT_BAL_T  
        add constraint IP_IND_REF1 
        foreign key (HLDG_IP_IND) 
        references END_IP_IND_T(IP_IND_CD);
    alter table END_CRNT_TAX_LOT_BAL_T  
        add constraint KEMID_REF2 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);
    alter table END_CRNT_TAX_LOT_BAL_T  
        add constraint REG_CD_REF1 
        foreign key (REGIS_CD) 
        references END_REGIS_CD_T(REGIS_CD);
    alter table END_CRNT_TAX_LOT_BAL_T  
        add constraint SEC_ID_REF1 
        foreign key (SEC_ID) 
        references END_SEC_T(SEC_ID);   
    
    
    create table END_CSH_SWEEP_MDL_T(
       CSH_SWEEP_MDL_ID DECIMAL(9) not null primary key,
       CSH_SWEEP_MDL_NM VARCHAR(100) not null,
       INC_SWEEP_LOWER_LMT DECIMAL(7,2) default '0.00' not null,
       INC_SWEEP_SEC_ID VARCHAR(9),
       INC_SWEEP_REGIS_CD VARCHAR(4),
       PRIN_SWEEP_LOWER_LMT DECIMAL(7,2) default '0.00' not null,
       CSH_SWEEP_FREQ VARCHAR(4) not null,
       CSH_SWEEP_MDL_DT DATE not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y',
       PRIN_SWEEP_SEC_ID VARCHAR(9) not null,
       PRIN_SWEEP_REGIS_CD VARCHAR(4) not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null
    );

    alter table END_CSH_SWEEP_MDL_T  
        add constraint INC_SWEEP_SEC_ID 
        foreign key (INC_SWEEP_SEC_ID) 
        references END_POOL_FND_CTRL_T(POOL_SEC_ID);
    alter table END_CSH_SWEEP_MDL_T  
        add constraint PRIN_SWEEP_SEC_ID 
        foreign key (PRIN_SWEEP_SEC_ID) 
        references END_POOL_FND_CTRL_T(POOL_SEC_ID);
    alter table END_CSH_SWEEP_MDL_T  
        add constraint INCOME_SWEEP_REG_CODE 
        foreign key (INC_SWEEP_REGIS_CD) 
        references END_REGIS_CD_T(REGIS_CD);
    alter table END_CSH_SWEEP_MDL_T  
        add constraint PRINCIPAL_SWEEP_REG_CODE 
        foreign key (PRIN_SWEEP_REGIS_CD) 
        references END_REGIS_CD_T(REGIS_CD);
        
        
    create table END_DONR_STMT_CD_T(
       DONR_STMT_CD VARCHAR(5) not null primary key,
       DONR_STMT_DESC VARCHAR(50) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null
    );        
    
 
    create table END_DONR_T(
       DONR_ID VARCHAR(10) not null,
       FIRST_NM VARCHAR(36),
       MID_NM VARCHAR(36),
       LAST_NM VARCHAR(36),
       ADDR1 VARCHAR(36),
       ADDR2 VARCHAR(36),
       ADDR3 VARCHAR(36),
       CITY VARCHAR(36),
       ST VARCHAR(2),
       PSTL_CD VARCHAR(15),
       CNTRY VARCHAR(2),
       PHN_NBR VARCHAR(15),
       INDIV_SLTN VARCHAR(80),
       INDIV_MAIL_LBL VARCHAR(80),
       JNT_SLTN VARCHAR(80),
       JNT_MAIL_LBL VARCHAR(80),
       DEVEL_OFFCR VARCHAR(80),
       DEC_DT DATE,
       CORP_NM1 VARCHAR(80),
       CORP_TTL1 VARCHAR(80),
       CORP_NM2 VARCHAR(80),
       CORP_TTL2 VARCHAR(80),
       CMNT VARCHAR(300),
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (DONR_ID)
    );
    
    
    create table END_ETRAN_CD_T(
       ETRAN_CD VARCHAR(9) not null,
       ETRAN_CD_DESC VARCHAR(120) not null,
       ETRAN_TYP_CD VARCHAR(1) not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       primary key (ETRAN_CD)
    );

    alter table END_ETRAN_CD_T  
        add constraint ETRAN_TYP_CD_REF1 
        foreign key (ETRAN_TYP_CD) 
        references END_ETRAN_TYP_CD_T(ETRAN_TYP_CD);
 
    
    create table END_ETRAN_TYP_CD_T(
        ETRAN_TYP_CD VARCHAR(1) not null primary key,
       ETRAN_TYP_DESC VARCHAR(40) not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null
    );
      
      
    create table END_ETRAN_GL_LNK_T(
        ETRAN_CD VARCHAR(9) not null,
       CHART_CD VARCHAR(2) not null,
       OBJECT VARCHAR(4),
       OBJ_ID VARCHAR(36),
       VER_NBR DECIMAL(8) default '1' not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       primary key (ETRAN_CD,CHART_CD)
    );

    alter table END_ETRAN_GL_LNK_T  
        add constraint ETRAN_GL_LNK_CHART_CD 
        foreign key (CHART_CD) 
        references CA_CHART_T(FIN_COA_CD);
    alter table END_ETRAN_GL_LNK_T  
        add constraint ETRAN_GL_LNK_ETRAN_CD 
        foreign key (ETRAN_CD) 
        references END_ETRAN_CD_T(ETRAN_CD);
   
   
    create table END_ETRAN_TYP_CD_T(
       ETRAN_TYP_CD VARCHAR(1) not null primary key,
       ETRAN_TYP_DESC VARCHAR(40) not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
    );
    
    
    create table END_FND_SRC_CD_T(
       FND_SRC_CD VARCHAR(5) not null,
       FND_SRC_DESC VARCHAR(36) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (FND_SRC_CD)
    );
    

    create table END_FREQ_CD_T(
        FREQ_CD VARCHAR(4) not null primary key,
       FREQ_DESC VARCHAR(150),
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null unique
    );
    

    create table END_HIST_CSH_T(
       KEMID VARCHAR(10) not null,
       ME_DT_ID DECIMAL(3) not null,
       HIST_INC_CSH DECIMAL(19,2) default '0.00' not null,
       HIST_PRIN_CSH DECIMAL(19,2) default '0.00' not null,
       OBJ_ID VARCHAR(36) not null,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (KEMID,ME_DT_ID)
    );

    alter table END_HIST_CSH_T  
        add constraint HIST_CSH_KEMID_REF1 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);
    alter table END_HIST_CSH_T  
        add constraint ME_DATE_ID 
        foreign key (ME_DT_ID) 
        references END_ME_DT_T(ME_DT_ID);
    
 
   create table END_HLDG_HIST_T(
       KEMID VARCHAR(10) not null,
       ME_DT_ID DECIMAL(3) not null,
       SEC_ID VARCHAR(9) not null,
       REGIS_CD VARCHAR(4) not null,
       HLDG_LOT_NBR DECIMAL(4) default '1' not null,
       HLDG_IP_IND VARCHAR(1) not null,
       HLDG_UNITS DECIMAL(16,4) default '0.0000' not null,
       HLDG_COST DECIMAL(19,2) default '0.00' not null,
       HLDG_ANNL_INC_EST DECIMAL(19,2) default '0.00' not null,
       SEC_UNIT_VAL DECIMAL(19,5) not null,
       HLDG_ACQD_DT DATE not null,
       HLDG_PRIOR_ACRD_INC DECIMAL(19,2) default '0' not null,
       HLDG_ACRD_INC_DUE DECIMAL(19,5) default '0' not null,
       LAST_TRAN_DT DATE not null,
       HLDG_MVAL DECIMAL(19,2) not null,
       OBJ_ID VARCHAR(36) not null,
       VER_NBR DECIMAL(8) default '1' not null,
       HLDG_FRGN_TAX_WITH DECIMAL(19,5) not null,
       AVG_MVAL DECIMAL(19,2),
       HLDG_FY_REM_EST_INC DECIMAL(19,2) not null,
       HLDG_NEXT_FY_EST_INC DECIMAL(19,2) not null,
       primary key (KEMID,ME_DT_ID,SEC_ID,REGIS_CD,HLDG_LOT_NBR,HLDG_IP_IND)
    );

    alter table END_HLDG_HIST_T  
        add constraint KEMID_REF1 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);
    alter table END_HLDG_HIST_T  
        add constraint ME_DATE_ID_REF1 
        foreign key (ME_DT_ID) 
        references END_ME_DT_T(ME_DT_ID);
    alter table END_HLDG_HIST_T  
        add constraint REGISTRATION_CODE 
        foreign key (REGIS_CD) 
        references END_REGIS_CD_T(REGIS_CD);
    alter table END_HLDG_HIST_T  
        add constraint SECURITY_ID 
        foreign key (SEC_ID) 
        references END_SEC_T(SEC_ID);
           

   create table END_HLDG_TAX_LOT_T(
       KEMID VARCHAR(10) not null,
       SEC_ID VARCHAR(9) not null,
       REGIS_CD VARCHAR(4) not null,
       HLDG_LOT_NBR DECIMAL(4) not null,
       HLDG_IP_IND VARCHAR(1) not null,
       HLDG_UNITS DECIMAL(16,4),
       HLDG_COST DECIMAL(19,2),
       HLDG_ACQD_DT DATE,
       HLDG_PRIOR_ACRD_INC DECIMAL(19,2) default '0',
       HLDG_ACRD_INC_DUE DECIMAL(19,5) default '0',
       LAST_TRAN_DT DATE,
       OBJ_ID VARCHAR(36) not null,
       VER_NBR DECIMAL(8) default '1' not null,
       HLDG_FRGN_TAX_WITH DECIMAL(19,5) not null,
       primary key (KEMID,SEC_ID,REGIS_CD,HLDG_LOT_NBR,HLDG_IP_IND)
    );

    alter table END_HLDG_TAX_LOT_T  
        add constraint HLDG_TAX_LOT_KEMID_REF1 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);
    alter table END_HLDG_TAX_LOT_T  
        add constraint REGISTRATION_CODE_REF1 
        foreign key (REGIS_CD) 
        references END_REGIS_CD_T(REGIS_CD);
    alter table END_HLDG_TAX_LOT_T  
        add constraint SECURITY_ID_REF1 
        foreign key (SEC_ID) 
        references END_SEC_T(SEC_ID);
        

   create table END_IP_IND_T(
       IP_IND_CD VARCHAR(1) not null,
       IP_IND_DESC VARCHAR(150),
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null unique,
       primary key (IP_IND_CD)
    );     
    
        
    create table END_KEMID_T(
       KEMID VARCHAR(10) not null,
       SHRT_TTL VARCHAR(50) not null,
       LONG_TTL VARCHAR(255) not null,
       OPND_DT DATE not null,
       ESTBL_DT DATE not null,
       TYP_CD VARCHAR(4) not null,
       PRPS_CD VARCHAR(4) not null,
       INC_CAE_CD VARCHAR(1),
       PRIN_CAE_CD VARCHAR(1),
       RESP_ADMIN_CD VARCHAR(4) not null,
       TRAN_RESTR_CD VARCHAR(5) not null,
       DORMANT_IND VARCHAR(1) default 'N' not null;
       INC_ACI_MDL_ID DECIMAL(9) not null,
       PRIN_ACI_MDL_ID DECIMAL(9) not null,
       CLOSED_IND VARCHAR(1) default 'N',
       CLOSED_TO_KEMID VARCHAR(10),
       CLS_CD VARCHAR(3),
       CSH_SWEEP_MDL_ID DECIMAL(9) not null,
       FND_DISP VARCHAR(150),
       CLOSE_DT DATE,
       VER_NBR DECIMAL(15,5) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID)
    );

    alter table END_KEMID_T  
        add constraint KEMID_INC_ACI_MDL_ID_FK 
        foreign key (INC_ACI_MDL_ID) 
        references END_AUTO_CSH_INVEST_MDL_T(ACI_MDL_ID);
    alter table END_KEMID_T  
        add constraint KEMID_PRIN_ACI_MDL_ID_FK 
        foreign key (PRIN_ACI_MDL_ID) 
        references END_AUTO_CSH_INVEST_MDL_T(ACI_MDL_ID);
    alter table END_KEMID_T  
        add constraint KEMID_CSH_SWEEP_MDL_ID_FK 
        foreign key (CSH_SWEEP_MDL_ID) 
        references END_CSH_SWEEP_MDL_T(CSH_SWEEP_MDL_ID);
    alter table END_KEMID_T  
        add constraint KEMID_PRPS_REF1 
        foreign key (PRPS_CD) 
        references END_PRPS_CD_T(PRPS_CD);
    alter table END_KEMID_T  
        add constraint KEMID_TYP_CD_FK 
        foreign key (TYP_CD) 
        references END_TYP_T(TYP_CD);
    alter table END_KEMID_T  
        add constraint KEMID_INC_CAE_CD_FK 
        foreign key (INC_CAE_CD) 
        references END_CAE_CD_T(CAE_CD);  
    alter table END_KEMID_T  
        add constraint KEMID_PRIN_CAE_CD_FK 
        foreign key (PRIN_CAE_CD) 
        references END_CAE_CD_T(CAE_CD);   
    alter table END_KEMID_T  
        add constraint KEMID_RESP_ADMIN_CD_FK 
        foreign key (RESP_ADMIN_CD) 
        references END_RESP_ADMIN_CD_T(RESP_ADMIN_CD);
    alter table END_KEMID_T  
        add constraint KEMID_TRAN_RESTR_CD_FK 
        foreign key (TRAN_RESTR_CD) 
        references END_TRAN_RESTR_CD_T(TRAN_RESTR_CD); 
    alter table END_KEMID_T
        add constraint KEMID_CLS_CD_FK 
        foreign key (CLS_CD) 
        references END_CLS_CD_T(SEC_CLS_CD); 
    
    create table END_ME_DT_T(
       ME_DT_ID DECIMAL(3) not null,
       ME_DT DATE not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (ME_DT_ID)
    );
   
   
    create table END_POOL_FND_CTRL_T(
        POOL_SEC_ID VARCHAR(9) not null,
       POOL_FND_DESC VARCHAR(120),
       PF_BATCH_ID VARCHAR(5),
       INCRM_VLTN_DATE DECIMAL(3) default '0',
       KEMID VARCHAR(10),
       AST_PURCH_OFST_CD VARCHAR(9),
       AST_SALE_OFST_CD VARCHAR(9),
       SALE_GAIN_LOSS_CD VARCHAR(9),
       CSH_DPST_OFST_CD VARCHAR(9),
       DSTRB_GAIN_LOSS_IND VARCHAR(1),
       ROW_ACTV_IND VARCHAR(1) default 'Y',
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (POOL_SEC_ID)
    );

    alter table END_POOL_FND_CTRL_T  
        add constraint AST_PURCH_OFST_CD 
        foreign key (AST_PURCH_OFST_CD) 
        references END_ETRAN_CD_T(ETRAN_CD);
    alter table END_POOL_FND_CTRL_T  
        add constraint AST_SALE_OFST_CD 
        foreign key (AST_SALE_OFST_CD) 
        references END_ETRAN_CD_T(ETRAN_CD);
    alter table END_POOL_FND_CTRL_T  
        add constraint SALE_GAIN_LOSS_CD 
        foreign key (SALE_GAIN_LOSS_CD) 
        references END_ETRAN_CD_T(ETRAN_CD);
    alter table END_POOL_FND_CTRL_T  
        add constraint CSH_DPST_OFST_CD 
        foreign key (CSH_DPST_OFST_CD) 
        references END_ETRAN_CD_T(ETRAN_CD);
    alter table END_POOL_FND_CTRL_T  
        add constraint POOL_FND_CTRL_KEMID_REF1 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);
    alter table END_POOL_FND_CTRL_T  
        add constraint POOLED_SECURITY_ID 
        foreign key (POOL_SEC_ID) 
        references END_SEC_T(SEC_ID);
        
    
     create table END_POOL_FND_VAL_T(
       POOL_SEC_ID VARCHAR(9) not null,
       VAL_EFF_DT DATE not null,
       VAL_DT DATE not null,
       DSTRB_AMT DECIMAL(19,5) default '0' not null,
       DSTRB_PROC_ON_DT DATE,
       DSTRB_PROC_CMPLT VARCHAR(1) default 'N' not null,
       LT_GAIN_LOSS DECIMAL(19,5) default '0' not null,
       LT_PROC_ON_DT DATE,
       LT_PROC_CMPLT VARCHAR(1) default 'N' not null,
       ST_PROC_CMPLT VARCHAR(1) default 'N' not null,
       ST_GAIN_LOSS DECIMAL(19,5) default '0' not null,
       ST_PROC_ON_DT DATE,
       OBJ_ID VARCHAR(36) not null,
       VER_NBR DECIMAL(8) default '1' not null,
       POOL_FND_UNIT_VAL DECIMAL(19,5) default '1' not null,
       primary key (POOL_SEC_ID,VAL_EFF_DT)
    );

    alter table END_POOL_FND_VAL_T  
        add constraint POOL_SECURITY_ID_REF1 
        foreign key (POOL_SEC_ID) 
        references END_POOL_FND_CTRL_T(POOL_SEC_ID);
        
        
    create table END_PRPS_CD_T(
       PRPS_CD VARCHAR(4) not null,
       PRPS_DESC VARCHAR(100) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (PRPS_CD)
    );
    
        
    create table END_REGIS_CD_T(
       REGIS_CD VARCHAR(4) not null,
       REGIS_CD_DESC VARCHAR(50),
       ROW_ACTV_IND VARCHAR(1) default 'Y',
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (REGIS_CD)
    ); 
       
       
    create table END_RESP_ADMIN_CD_T(
       RESP_ADMIN_CD VARCHAR(4) not null,
       RESP_ADMIN_DESC VARCHAR(36) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (RESP_ADMIN_CD)
    );   
    
    
    create table END_ROLE_CD_T(
       ROLE_CD VARCHAR(6) not null,
       ROLE_DESC VARCHAR(36) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (ROLE_CD)
    );    
    
    create table END_SEC_RPT_GRP_T(
       SEC_RPT_GRP VARCHAR(5) not null,
       SEC_RPT_GRP_DESC VARCHAR(50),
       SEC_RPT_GRP_ORD DECIMAL(2),
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (SEC_RPT_GRP)
    );
    

    create table END_SEC_T(
       SEC_ID VARCHAR(9) not null,
       SEC_DESC VARCHAR(120),
       SEC_TKR_SYMB VARCHAR(6),
       SEC_CLS_CD VARCHAR(3),
       SEC_SUBCLS_CD VARCHAR(3),
       SEC_MAT_DT DATE,
       SEC_UNIT_VAL DECIMAL(19,5) default '1',
       SEC_UNITS_HELD DECIMAL(16,5) default '0',
       SEC_VAL_DT DATE,
       UNIT_VAL_SRC VARCHAR(30),
       PREV_UNIT_VAL DECIMAL(19,5),
       PREV_UNIT_VAL_DT DATE,
       SEC_CVAL DECIMAL(19,2) default '0',
       LAST_TRAN_DT DATE,
       SEC_INC_PAY_FREQ VARCHAR(4),
       SEC_INC_NEXT_PAY_DT DATE,
       SEC_RT DECIMAL(19,5),
       SEC_INC_CHG_DT DATE,
       SEC_ISS_DT DATE,
       SEC_DVDND_REC_DT DATE,
       SEC_EX_DVDND_DT DATE,
       SEC_DVDND_PAY_DT DATE,
       SEC_DVDND_AMT DECIMAL(19,4),
       CMTMNT_AMT DECIMAL(19,2),
       FRGN_WITH_PCT DECIMAL(5,4) default '0.00',
       ROW_ACTV_IND VARCHAR(1) default 'Y',
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       NXT_FSCL_YR_DSTRB_AMT DECIMAL(19,2),
       primary key (SEC_ID)
    );

    alter table END_SEC_T  
        add constraint SECURITY_CLASS_CODE_REF1 
        foreign key (SEC_CLS_CD) 
        references END_CLS_CD_T(SEC_CLS_CD);
    alter table END_SEC_T  
        add constraint SECURITY_SUBCLASS_CODE_REF1 
        foreign key (SEC_SUBCLS_CD) 
        references END_SUBCLS_CD_T(SEC_SUBCLS_CD);
        
    
    create table END_SEC_VLTN_MTHD_T(
       VLTN_MTHD VARCHAR(1) not null,
       VLTN_MTHD_DESC VARCHAR(40),
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (VLTN_MTHD)
    );
  
    create table END_SUBCLS_CD_T(
       SEC_SUBCLS_CD VARCHAR(3) not null,
       SEC_SUBCLS_CD_DESC VARCHAR(150) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (SEC_SUBCLS_CD)
    );
    
    
    create table END_TKLR_TYP_CD_T(
        TKLR_TYP_CD VARCHAR(5) not null,
       TKLR_TYP_DESC VARCHAR(36) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (TKLR_TYP_CD)
    );
    
    
    create table END_TRAN_RESTR_CD_T(
        TRAN_RESTR_CD VARCHAR(5) not null,
       TRAN_RESTR_DESC VARCHAR(36) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (TRAN_RESTR_CD)
    );
    
 

    create table END_TYP_RESTR_CD_T(
       TYP_RESTR_CD VARCHAR(3) not null,
       TYP_RESTR_DESC VARCHAR(36) not null,
       PERM VARCHAR(1) default 'N' not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (TYP_RESTR_CD)
    );   
    
    
    create table END_TYP_T(
       TYP_CD VARCHAR(3) not null,
       TYP_DESC VARCHAR(100) not null,
       TYP_INC_RESTR_CD VARCHAR(3) not null,
       TYP_PRIN_RESTR_CD VARCHAR(3) not null,
       TYP_CSH_SWEEP_MDL_ID DECIMAL(9) not null,
       TYP_INC_ACI_MDL_ID DECIMAL(9) not null,
       TYP_PRIN_ACI_MDL_ID DECIMAL(9) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (TYP_CD)
    );

    alter table END_TYP_T  
        add constraint TYP_INC_ACI_MDL_ID 
        foreign key (TYP_INC_ACI_MDL_ID) 
        references END_AUTO_CSH_INVEST_MDL_T(ACI_MDL_ID);
    alter table END_TYP_T  
        add constraint TYP_PRIN_ACI_MDL_ID 
        foreign key (TYP_PRIN_ACI_MDL_ID) 
        references END_AUTO_CSH_INVEST_MDL_T(ACI_MDL_ID);
    alter table END_TYP_T  
        add constraint TYP_CSH_SWEEP_MDL_ID 
        foreign key (TYP_CSH_SWEEP_MDL_ID) 
        references END_CSH_SWEEP_MDL_T(CSH_SWEEP_MDL_ID);
    alter table END_TYP_T  
        add constraint TYP_INC_RESTR_CD 
        foreign key (TYP_INC_RESTR_CD) 
        references END_TYP_RESTR_CD_T(TYP_RESTR_CD);
    alter table END_TYP_T  
        add constraint TYP_PRIN_RESTR_CD 
        foreign key (TYP_PRIN_RESTR_CD) 
        references END_TYP_RESTR_CD_T(TYP_RESTR_CD);    
        

    create table END_USE_CRIT_T(
       USE_CRIT_CD VARCHAR(5) not null,
       USE_CRIT_DESC VARCHAR(100) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null unique,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (USE_CRIT_CD)
    );             
    
    
-- create end_fee_rt_def_cd_t table

CREATE TABLE END_FEE_RT_DEF_CD_T (
	FEE_RT_DEF_CD	VARCHAR(1) NOT NULL,
	FEE_RT_DEF_DESC	VARCHAR(5) NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1' NOT NULL
);

-- create constraints for end_fee_rt_def_cd_t table

ALTER TABLE END_FEE_RT_DEF_CD_T
	ADD CONSTRAINT END_FEE_RT_DEF_CD_PK
	PRIMARY KEY (FEE_RT_DEF_CD);


-- create end_fee_typ_cd_t table

CREATE TABLE END_FEE_TYP_CD_T (
	FEE_TYP_CD	VARCHAR(1) NOT NULL,
	FEE_TYP_DESC	VARCHAR(12) NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1' NOT NULL	
);

-- create constraints for end_fee_typ_cd_t table

ALTER TABLE END_FEE_TYP_CD_T
	ADD CONSTRAINT END_FEE_TYP_CD_PK
	PRIMARY KEY (FEE_TYP_CD);


-- create end_fee_bal_typ_cd_t table

CREATE TABLE END_FEE_BAL_TYP_CD_T (
	FEE_BAL_TYP_CD		VARCHAR(3) NOT NULL,
	FEE_BAL_TYP_DESC	VARCHAR(22) NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1' NOT NULL	
);

-- create constraints for end_fee_bal_typ_cd_t table

ALTER TABLE END_FEE_BAL_TYP_CD_T
	ADD CONSTRAINT END_FEE_BAL_TYP_CD_PK
	PRIMARY KEY (FEE_BAL_TYP_CD);


-- create end_fee_base_cd_t table

CREATE TABLE END_FEE_BASE_CD_T (
	FEE_BASE_CD		VARCHAR(1) NOT NULL,
	FEE_BASE_DESC		VARCHAR(9) NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1' NOT NULL	
);

-- create constraints for end_fee_typ_cd_t table

ALTER TABLE END_FEE_BASE_CD_T
	ADD CONSTRAINT END_FEE_BASE_CD_PK
	PRIMARY KEY (FEE_BASE_CD);


-- create table end_pmt_typ_cd_t

CREATE TABLE END_PMT_TYP_CD_T (
	PMT_TYP_CD	VARCHAR(1) NOT NULL,
	PMT_TYP_DESC	VARCHAR(5) NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1' NOT NULL	
);

-- create constraints for table end_pmt_typ_cd_t

ALTER TABLE END_PMT_TYP_CD_T
	ADD CONSTRAINT END_PMT_TYP_CD_PK
	PRIMARY KEY (PMT_TYP_CD);


-- create table end_tran_typ_t

CREATE TABLE END_TRAN_TYP_CD_T (
	TRAN_TYP_CD	VARCHAR(1) NOT NULL,
	TRAN_TYP_DESC	VARCHAR(10) NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1' NOT NULL	
);

-- create constraints for table end_tran_typ_cd_t

ALTER TABLE END_TRAN_TYP_CD_T
	ADD CONSTRAINT END_TRAN_TYP_CD_PK
	PRIMARY KEY (TRAN_TYP_CD);


-- create end_fee_mtdh_t table

CREATE TABLE END_FEE_MTHD_T (
	FEE_MTHD		VARCHAR(12)	NOT NULL,
	FEE_MTHD_DESC		VARCHAR(50)	NOT NULL,
	FEE_FREQ_CD		VARCHAR(4)	NOT NULL,
	FEE_NXT_PROC_DT		DATE,
	FEE_LST_PROC_DT		DATE,
	FEE_RT_DEF_CD		VARCHAR(1)	NOT NULL,
	FEE_RT_1		DECIMAL(9,4)	DEFAULT 0.0000	NOT NULL,
	FEE_BRK_1		DECIMAL(19,2)	DEFAULT 99999999999999999.99 NOT NULL,	
	FEE_RT_2		DECIMAL(9,4)	DEFAULT 0.0000	NOT NULL,
	FEE_BRK_2		DECIMAL(19,2)	DEFAULT 99999999999999999.99 NOT NULL,
	FEE_RT_3		DECIMAL(9,4)	DEFAULT 0.0000	NOT NULL,
	FEE_MIN_AMT		DECIMAL(4,2)	DEFAULT 0,
	FEE_TYP_CD		VARCHAR(1)	NOT NULL,
	FEE_BASE_CD		VARCHAR(1)	NOT NULL,
	FEE_EXP_ETRAN_CD	VARCHAR(9)	NOT NULL,
	FEE_POST_PEND_IND	VARCHAR(1)	DEFAULT 'N'	NOT NULL,
	CORPUS_PCT_TLRNC	DECIMAL(5,2),
	FEE_BAL_TYP_CD		VARCHAR(3)	NOT NULL,
	FEE_BY_CLS_CD		VARCHAR(1)	DEFAULT 'N',
	FEE_BY_SEC_ID		VARCHAR(1)	DEFAULT 'N',
	FEE_BY_TRAN_TYP		VARCHAR(1)	DEFAULT 'N',
	FEE_BY_ETRAN_CD		VARCHAR(1)	DEFAULT 'N',
	ROW_ACTV_IND		VARCHAR(1)	DEFAULT 'Y'	NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1'  NOT NULL
);

-- create constraints for end_fee_mtdh_t table

ALTER TABLE END_FEE_MTHD_T
	ADD CONSTRAINT END_FEE_MTHD_PK
	PRIMARY KEY (FEE_MTHD);

ALTER TABLE END_FEE_MTHD_T
	ADD CONSTRAINT END_FEE_MTHD_FK2
	FOREIGN KEY (FEE_TYP_CD) REFERENCES
	END_FEE_TYP_CD_T (FEE_TYP_CD);

ALTER TABLE END_FEE_MTHD_T
	ADD CONSTRAINT END_FEE_MTHD_FK3
	FOREIGN KEY (FEE_BAL_TYP_CD) REFERENCES
	END_FEE_BAL_TYP_CD_T (FEE_BAL_TYP_CD);

ALTER TABLE END_FEE_MTHD_T
	ADD CONSTRAINT END_FEE_MTHD_FK4
	FOREIGN KEY (FEE_FREQ_CD) REFERENCES
	END_FREQ_CD_T (FREQ_CD);

ALTER TABLE END_FEE_MTHD_T
	ADD CONSTRAINT END_FEE_MTHD_FK6
	FOREIGN KEY (FEE_EXP_ETRAN_CD) REFERENCES
	END_ETRAN_CD_T (ETRAN_CD);

ALTER TABLE END_FEE_MTHD_T
	ADD CONSTRAINT END_FEE_MTHD_FK8
	FOREIGN KEY (FEE_RT_DEF_CD) REFERENCES
	END_FEE_RT_DEF_CD_T (FEE_RT_DEF_CD);

ALTER TABLE END_FEE_MTHD_T
	ADD CONSTRAINT END_FEE_MTHD_FK9
	FOREIGN KEY (FEE_BASE_CD) REFERENCES
	END_FEE_BASE_CD_T (FEE_BASE_CD);


    create table END_TYP_FEE_MTHD_T(
        TYP_CD VARCHAR(3) not null,
       FEE_MTHD VARCHAR(10) not null,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       OBJ_ID VARCHAR(36) not null,
       VER_NBR DECIMAL(8) default '1' not null,
       primary key (TYP_CD,FEE_MTHD)
    );

    alter table END_TYP_FEE_MTHD_T  
        add constraint TYP_CD_REF1 
        foreign key (TYP_CD) 
        references END_TYP_T(TYP_CD);

    ALTER TABLE END_TYP_FEE_MTHD_T
	ADD CONSTRAINT END_TYP_FEE_MTHD_FK2
	FOREIGN KEY (FEE_MTHD) REFERENCES
	END_FEE_MTHD_T (FEE_MTHD);

-- create table end_fee_cls_cd_t

CREATE TABLE END_FEE_CLS_CD_T (
	FEE_MTHD	VARCHAR(12)	NOT NULL,
	SEC_CLS_CD	VARCHAR(3)	NOT NULL,
	INCL		VARCHAR(1)	DEFAULT 'Y'	NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1'  NOT NULL	
);

-- create constraints for the table end_fee_cls_cd_t

	ALTER TABLE END_FEE_CLS_CD_T
		ADD CONSTRAINT END_FEE_CLS_CD_PK
		PRIMARY KEY (FEE_MTHD, SEC_CLS_CD);

	ALTER TABLE END_FEE_CLS_CD_T
		ADD CONSTRAINT END_FEE_CLS_CD_FK1
		FOREIGN KEY (FEE_MTHD) REFERENCES
		END_FEE_MTHD_T;

	ALTER TABLE END_FEE_CLS_CD_T
		ADD CONSTRAINT END_FEE_CLS_CD_FK2
		FOREIGN KEY (SEC_CLS_CD) REFERENCES
		END_CLS_CD_T;


-- create table end_fee_sec_t


CREATE TABLE END_FEE_SEC_T (
	FEE_MTHD	VARCHAR(12)	NOT NULL,
	SEC_ID		VARCHAR(9)	NOT NULL,
	INCL		VARCHAR(1)	DEFAULT 'Y'	NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1'  NOT NULL		
);

-- create constraints for the table end_fee_sec_t

	ALTER TABLE END_FEE_SEC_T
		ADD CONSTRAINT END_FEE_SEC_PK
		PRIMARY KEY (FEE_MTHD, SEC_ID);

	ALTER TABLE END_FEE_SEC_T
		ADD CONSTRAINT END_FEE_SEC_FK1
		FOREIGN KEY (FEE_MTHD) REFERENCES
		END_FEE_MTHD_T;

	ALTER TABLE END_FEE_SEC_T
		ADD CONSTRAINT END_FEE_SEC_FK2
		FOREIGN KEY (SEC_ID) REFERENCES
		END_SEC_T;


-- create table end_fee_pmt_type_t


CREATE TABLE END_FEE_PMT_TYP_T (
	FEE_MTHD	VARCHAR(12)	NOT NULL,
	PMT_TYP_CD	VARCHAR(1)	NOT NULL,
	INCL		VARCHAR(1)	DEFAULT 'Y'	NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1'  NOT NULL		
);

-- create constraints for the table end_fee_sec_t

	ALTER TABLE END_FEE_PMT_TYP_T 
		ADD CONSTRAINT END_FEE_PMT_TYP_PK
		PRIMARY KEY (FEE_MTHD);

	ALTER TABLE END_FEE_PMT_TYP_T 
		ADD CONSTRAINT END_FEE_PMT_TYP_FK2
		FOREIGN KEY (FEE_MTHD) REFERENCES
		END_FEE_MTHD_T;

	ALTER TABLE END_FEE_PMT_TYP_T 
		ADD CONSTRAINT END_FEE_PMT_TYP_FK1
		FOREIGN KEY (PMT_TYP_CD) REFERENCES
		END_PMT_TYP_CD_T;

-- create table end_fee_tran_typ_t

CREATE TABLE END_FEE_TRAN_TYP_T (
	FEE_MTHD	VARCHAR(12)	NOT NULL,
	TRAN_TYP_CD	VARCHAR(1)	NOT NULL,
	INCL		VARCHAR(1)	DEFAULT 'Y'	NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1'  NOT NULL		
);

-- create constraints for the table end_fee_tran_typ_t

	ALTER TABLE END_FEE_TRAN_TYP_T 
		ADD CONSTRAINT END_FEE_TRAN_TYP_PK
		PRIMARY KEY (FEE_MTHD, TRAN_TYP_CD);

	ALTER TABLE END_FEE_TRAN_TYP_T 
		ADD CONSTRAINT END_FEE_TRAN_TYP_FK1
		FOREIGN KEY (FEE_MTHD) REFERENCES
		END_FEE_MTHD_T;

	ALTER TABLE END_FEE_TRAN_TYP_T 
		ADD CONSTRAINT END_FEE_TRAN_TYP_FK2
		FOREIGN KEY (TRAN_TYP_CD) REFERENCES
		END_TRAN_TYP_CD_T;


-- create table end_fee_etran_cd_t

CREATE TABLE END_FEE_ETRAN_CD_T (
	FEE_MTHD	VARCHAR(12)	NOT NULL,
	ETRAN_CD	VARCHAR(9)	NOT NULL,
	INCL		VARCHAR(1)	DEFAULT 'Y'	NOT NULL,
	OBJ_ID VARCHAR(36) NOT NULL UNIQUE,
	VER_NBR DECIMAL(8,0) DEFAULT '1'  NOT NULL		
);

-- create constraints for the table end_fee_tran_typ_t

	ALTER TABLE END_FEE_ETRAN_CD_T 
		ADD CONSTRAINT END_FEE_ETRAN_CD_PK
		PRIMARY KEY (FEE_MTHD, ETRAN_CD);

	ALTER TABLE END_FEE_ETRAN_CD_T 
		ADD CONSTRAINT END_FEE_ETRAN_CD_FK1
		FOREIGN KEY (FEE_MTHD) REFERENCES
		END_FEE_MTHD_T;
    
-- create KEMID related tables

    create table END_ENDOW_CORPUS_T(
       KEMID VARCHAR(10) not null,
       CORPUS_VAL_HIST_DT DATE not null,
       CORPUS_VAL DECIMAL(19,2) not null,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID,CORPUS_VAL_HIST_DT)
    );
    
    alter table END_ENDOW_CORPUS_T 
        add constraint END_ENDOW_CORPUS_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);
        

    create table END_CURR_ENDOW_CORPUS_T(
       KEMID VARCHAR(10) not null,
       CORPUS_VAL DECIMAL(19,2) not null,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID)
    );

    alter table END_CURR_ENDOW_CORPUS_T  
        add constraint END_CURR_ENDOW_CORPUS_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);   
         
        
    create table END_KEMID_AGRMNT_T(
       KEMID VARCHAR(10) not null,
       AGRMNT_ID DECIMAL(2) not null,
       AGRMNT_TYP_CD VARCHAR(3) not null,
       AGRMNT_STAT_CD VARCHAR(4) default 'PEND' not null,
       AGRMNT_STAT_DT DATE not null,
       AGRMNT_OTHR_DOC VARCHAR(1024),
       DONR_INTNT_TXT VARCHAR(4000),
       CMNT VARCHAR(1024),
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID,AGRMNT_ID)
    );

    alter table END_KEMID_AGRMNT_T  
        add constraint END_KEMID_AGRMNT_KEMID_FK
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);     
    alter table END_KEMID_AGRMNT_T  
        add constraint END_KEMID_AGRMNT_TYP_CD_FK 
        foreign key (AGRMNT_TYP_CD) 
        references END_AGRMNT_TYP_CD_T(AGRMNT_TYP_CD); 
    alter table END_KEMID_AGRMNT_T  
        add constraint END_KEMID_AGRMNT_STAT_CD_FK 
        foreign key (AGRMNT_STAT_CD) 
        references END_AGRMNT_STAT_CD_T(AGRMNT_STAT_CD);         
           
        
    create table END_KEMID_BENE_ORG_T(
       KEMID VARCHAR(10) not null,
       BENE_ORG_SEQ DECIMAL(3) not null,
       BENE_ORG_CD VARCHAR(4) not null,
       BENE_PCT DECIMAL(3,2) not null,
       BENE_ORG_STRT_DT DATE not null,
       BENE_ORG_CHG_DT DATE,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID,BENE_ORG_SEQ,BENE_ORG_CD)
    );

    alter table END_KEMID_BENE_ORG_T  
        add constraint END_KEMID_BENE_ORG_KEMID_FK
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);        
        
        
   create table END_KEMID_CMB_GRP_T(
       KEMID VARCHAR(10) not null,
       CMB_SEQ DECIMAL(3) not null;
       CMB_GRP_ID VARCHAR(5) not null,
       CMB_DT DATE not null,
       TERM_CMB_DT DATE,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID,CMB_GRP_ID)
    );

    alter table END_KEMID_CMB_GRP_T  
        add constraint END_KEMID_CMB_GRP_ID_FK 
        foreign key (CMB_GRP_ID) 
        references END_CMB_GRP_T(CMB_GRP_ID);
    alter table END_KEMID_CMB_GRP_T  
        add constraint END_KEMID_CMB_GRP_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);        
        
        
    create table END_KEMID_CORPUS_VAL_T(
       KEMID VARCHAR(10) not null,
       CURR_CORPUS_VAL DECIMAL(19,2),
       CURR_PRIN_MVAL DECIMAL(19,2),
       PRIOR_FY_CORPUS_VAL DECIMAL(19,2),
       PRIOR_FY_PRIN_MVAL DECIMAL(19,2),
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID)
    );

    alter table END_KEMID_CORPUS_VAL_T  
        add constraint END_KEMID_CORPUS_VAL_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);    
        
        
    create table END_KEMID_DONR_T(
       KEMID VARCHAR(10) not null,
       DONR_ID VARCHAR(10) not null,
       DONR_SEQ DECIMAL(3) not null,
       DONR_STMT_CD VARCHAR(5) not null,
       CMB_DONR_ID VARCHAR(10),
       EFF_DT DATE not null,
       TERM_DT DATE,
       TERM_RSN VARCHAR(150),
       DONR_LBL_SEL VARCHAR(1) not null,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID,DONR_SEQ,DONR_ID)
    );

    alter table END_KEMID_DONR_T  
        add constraint END_KEMID_DONR_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);   
        
        
    create table END_KEMID_DONR_CMB_T(
       KEMID VARCHAR(10) not null,
       CMB_SEQ DECIMAL(3) not null,
       CMB_KEMID VARCHAR(10) not null,
       CMB_DT DATE not null,
       TERM_CMB_DT DATE,
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID,CMB_SEQ)
    );

    alter table END_KEMID_DONR_CMB_T  
        add constraint END_KEMID_DONR_CMB_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);           
       
       
    create table END_KEMID_FND_SRC_T(
       KEMID VARCHAR(10) not null,
       KEMID_FND_SRC_SEQ DECIMAL(3) not null,
       FND_SRC_CD VARCHAR(5) not null,
       OPND_FRM_KEMID VARCHAR(10),
       FND_HIST VARCHAR(250),
       FND_SRC_ADTNL_DTA VARCHAR(250),
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID,KEMID_FND_SRC_SEQ,FND_SRC_CD)
    );

    alter table END_KEMID_FND_SRC_T  
        add constraint END_KEMID_FND_SRC_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);     
    alter table END_KEMID_FND_SRC_T 
        add constraint END_KEMID_FND_SRC_CD_FK 
        foreign key (FND_SRC_CD) 
        references END_FND_SRC_CD_T(FND_SRC_CD); 
        
        
    create table END_KEMID_FEE_T(
       KEMID VARCHAR(10) not null,
       FEE_MTHD VARCHAR(12) not null,
       FEE_MTHD_SEQ DECIMAL(3) not null,
       CHRG_FEE_TO_KEMID VARCHAR(10) not null,
       PCT_CHRG_FEE_TO_INC DECIMAL(3,2) not null,
       PCT_CHRG_FEE_TO_PRIN DECIMAL(3,2),
       ACR_FEE VARCHAR(1) default 'N',
       ACRD_FEE_TO_DT DECIMAL(19,2),
       WAIVE_FEE VARCHAR(1) default 'N',
       WAIVED_FEE_YTD DECIMAL(19,2),
       WAIVED_FEE_TO_DT DECIMAL(19,2),
       FEE_IMPL_DT DATE not null,
       FEE_TERM_DT DATE,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID,FEE_MTHD,FEE_MTHD_SEQ)
    );

    alter table END_KEMID_FEE_T  
        add constraint END_KEMID_FEE_MTHD_FK 
        foreign key (FEE_MTHD) 
        references END_FEE_MTHD_T(FEE_MTHD);
    alter table END_KEMID_FEE_T  
        add constraint END_KEMID_FEE_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);          
        
        
    create table END_KEMID_USE_CRIT_T(
       KEMID VARCHAR(10) not null,
       USE_CRIT_SEQ DECIMAL(3) not null,
       USE_CRIT_CD VARCHAR(5) not null,
       USE_CRIT_ADTNL_DTA VARCHAR(150),
       ROW_ACTV_IND VARCHAR(1) default 'Y' not null,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID,USE_CRIT_SEQ,USE_CRIT_CD)
    );

    alter table END_KEMID_USE_CRIT_T  
        add constraint END_KEMID_USE_CRIT_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);
    alter table END_KEMID_USE_CRIT_T  
        add constraint END_KEMID_USE_CRIT_CD_FK 
        foreign key (USE_CRIT_CD) 
        references END_USE_CRIT_T(USE_CRIT_CD);   
        
        
    create table END_KEMID_PAY_INC_T(
       KEMID VARCHAR(10) not null,
       PAY_INC_SEQ DECIMAL(3) not null,
       PAY_INC_TO_KEMID VARCHAR(10) not null,
       PAY_INC_PCT DECIMAL(3,2) not null,
       PAY_INC_AMT DECIMAL(19,2),
       PAY_INC_STRT_DT DATE not null,
       PAY_INC_TERM_DT DATE,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
       primary key (KEMID,PAY_INC_SEQ,PAY_INC_TO_KEMID)
    );

    alter table END_KEMID_PAY_INC_T  
        add constraint END_KEMID_PAY_INC_TO_KEMID_FK 
        foreign key (PAY_INC_TO_KEMID) 
        references END_KEMID_T(KEMID);
    alter table END_KEMID_PAY_INC_T  
        add constraint END_KEMID_PAY_INC_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID); 
        
        
    create table END_KEMID_GL_LNK_T(
       KEMID VARCHAR(10) not null,
       IP_IND_CD VARCHAR(1) not null,
       CHRT_CD VARCHAR(2) not null,
       ACCT_NBR VARCHAR(7) not null,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
        primary key (KEMID,IP_IND_CD)
    );

    alter table END_KEMID_GL_LNK_T  
        add constraint END_KEMID_GL_LNK_IP_IND_CD_FK 
        foreign key (IP_IND_CD) 
        references END_IP_IND_T(IP_IND_CD);
    alter table END_KEMID_GL_LNK_T  
        add constraint END_KEMID_GL_LNK_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);                    
        
        
    create table END_KEMID_SPCL_INSTRC_T(
       KEMID VARCHAR(10) not null,
       INSTRC_SEQ DECIMAL(3) not null,
       AGRMNT_SPCL_INSTRC_CD VARCHAR(3) not null,
       CMNT VARCHAR(1024),
       INSTRC_EST_DT DATE not null,
       INSTRC_TERM_DT DATE,
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null,
      primary key (KEMID,INSTRC_SEQ,AGRMNT_SPCL_INSTRC_CD)
    );

    alter table END_KEMID_SPCL_INSTRC_T  
        add constraint END_KEMID_SPCL_INSTRC_CD_FK 
        foreign key (AGRMNT_SPCL_INSTRC_CD) 
        references END_AGRMNT_SPCL_INSTRC_CD_T(AGRMNT_SPCL_INSTRC_CD);
    alter table END_KEMID_SPCL_INSTRC_T  
        add constraint END_KEMID_SPCL_INSTRC_KEMID_FK 
        foreign key (KEMID) 
        references END_KEMID_T(KEMID);           
                                       
    create table END_DONR_LBL_SEL_T(
       DONR_LBL_SEL VARCHAR(1) not null,
       DONR_LBL_SEL_DESC VARCHAR(50),
       VER_NBR DECIMAL(8) default '1' not null,
       OBJ_ID VARCHAR(36) not null unique,
        primary key (DONR_LBL_SEL)
    );                                       