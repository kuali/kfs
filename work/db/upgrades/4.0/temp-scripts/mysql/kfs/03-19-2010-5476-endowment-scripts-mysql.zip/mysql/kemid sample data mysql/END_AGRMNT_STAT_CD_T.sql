insert into END_AGRMNT_STAT_CD_T (AGRMNT_STAT_CD, AGRMNT_STAT_DESC, AGRMNT_DFLT_TRAN_RESTR, ROW_ACTV_IND, OBJ_ID) values 
('COMP', 'Completed', 'NONE', 'Y',UUID()),
('DRFT', 'Draft', 'NDISB', 'Y',UUID()),
('NONE', 'Not Applicable', 'NONE', 'Y',UUID()),
('PEND', 'Pending', 'NDISB', 'Y',UUID());
