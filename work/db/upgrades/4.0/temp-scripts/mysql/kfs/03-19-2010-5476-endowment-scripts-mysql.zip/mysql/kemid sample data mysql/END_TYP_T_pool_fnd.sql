insert into END_TYP_T  (TYP_CD, TYP_DESC, TYP_INC_RESTR_CD, TYP_PRIN_RESTR_CD, TYP_CSH_SWEEP_MDL_ID, TYP_INC_ACI_MDL_ID, TYP_PRIN_ACI_MDL_ID, ROW_ACTV_IND, OBJ_ID) values 
('042', 'Trusts Held for Expendable Endowments (&income)- IU (custodial)', 'TRU', 'TRU', null, null, null, 'Y',UUID()),
('027', 'Permanent Trust Principal - IUF (custodial)', 'PRF', 'PRF', null, null, null, 'Y',UUID()),
('047', 'Permanent Trust Principal - IU (custodial)', 'PRU', 'PRU', null, null, null, 'Y',UUID()),
('049', 'Donor Foundation Unrestricted Trusts - IUF (custodial)', 'TRF', 'TRF', null, null, null, 'Y',UUID()),
('070', 'Real Estate Administration IU', 'TRU', 'TRU', null, null, null, 'Y',UUID()),
('099', 'Pooled Funds', 'OBS', 'OBS', null, null, null, 'Y',UUID()),
('909', 'TIPS', 'OBS', 'OBS', null, null, null, 'Y',UUID());