insert into END_KEMID_SPCL_INSTRC_T (KEMID, INSTRC_SEQ, AGRMNT_SPCL_INSTRC_CD, CMNT, INSTRC_EST_DT, INSTRC_TERM_DT, OBJ_ID) values 
('037A014184', '1', 'TP', '100% to I37A017013', STR_TO_DATE('11/1/2005', '%m/%d/%Y'),STR_TO_DATE('', '%m/%d/%Y'), UUID()),
('037AS12302', '1', 'RF', '" Any funds not awarded will be invested back into the principal until such time when the fund generates enough income to support 2-12 month fellowships"', STR_TO_DATE('11/9/2006', '%m/%d/%Y'),STR_TO_DATE('', '%m/%d/%Y'), UUID()),
('037B011AG1', '1', 'RE', '"Reinvest to $10,000"', STR_TO_DATE('11/1/2005', '%m/%d/%Y'),STR_TO_DATE('', '%m/%d/%Y'), UUID()),
('037E009727', '1', 'RE', '"RE-Interest income be reinvested through Dec. 31, 2010 in order to grow the principal per Gift Agreement   2.   Remove dollar restriction 5/31/2012"', STR_TO_DATE('12/10/2008', '%m/%d/%Y'),STR_TO_DATE('', '%m/%d/%Y'), UUID()),
('037G003785', '1', 'TP', 'Rotate each year (Odd Years) 100% to 37L006568 & (Even Years) 100% to 37AS19174  2.  When fund reaches $1Million close & create new endowments in L006 & AS19', STR_TO_DATE('11/1/2005', '%m/%d/%Y'),STR_TO_DATE('', '%m/%d/%Y'), UUID()),
('037H004261', '1', 'RE', '"Reinvest to $25,000."', STR_TO_DATE('11/1/2005', '%m/%d/%Y'),STR_TO_DATE('', '%m/%d/%Y'), UUID()),
('037H004261', '2', 'RE', '"Reinvest to $25,000."', STR_TO_DATE('11/1/2005', '%m/%d/%Y'),STR_TO_DATE('', '%m/%d/%Y'), UUID()),
('037P011291', '1', 'RF', 'only if no recipient.', STR_TO_DATE('11/1/2005', '%m/%d/%Y'),STR_TO_DATE('', '%m/%d/%Y'), UUID()),
('037RQ04222', '1', 'RF', 'only if no recipient', STR_TO_DATE('11/1/2005', '%m/%d/%Y'),STR_TO_DATE('', '%m/%d/%Y'), UUID()),
('037SC00501', '1', 'RF', 'only if no recipient.', STR_TO_DATE('11/1/2005', '%m/%d/%Y'),STR_TO_DATE('', '%m/%d/%Y'), UUID());
