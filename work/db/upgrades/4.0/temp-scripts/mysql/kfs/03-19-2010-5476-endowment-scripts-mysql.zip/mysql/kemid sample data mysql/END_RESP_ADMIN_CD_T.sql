insert into END_RESP_ADMIN_CD_T (RESP_ADMIN_CD, RESP_ADMIN_DESC, ROW_ACTV_IND, OBJ_ID) values 
('ACCT', 'Accounting', 'Y',UUID()),
('AGNC', 'Agency', 'Y',UUID()),
('GENA', 'General Administration', 'Y',UUID()),
('INTL', 'Internal', 'Y',UUID()),
('INVS', 'Investments', 'Y',UUID()),
('PLFD', 'Pooled Funds', 'Y',UUID()),
('TRST', 'Trust Accounting', 'Y',UUID());
