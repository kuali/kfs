create view END_KEMID_HIST_REP_GRP_V as
select
C.KEMID,
CL.SEC_RPT_GRP,
C.sec_id,
C.regis_cd,
C.HLDG_IP_IND,
sum(C.HLDG_UNITS) as UNITS,
sum(HLDG_COST) as CARRY_VAL,
sum(HLDG_MVAL) as MARKET_VAL,
sum(HLDG_NEXT_FY_EST_INC) as NEXT_FY_EST_INC,
sum(HLDG_FY_REM_EST_INC) as FY_REM_EST_INC,
sum(HLDG_ANNL_INC_EST) as ANNL_INC_EST,
C.ME_DT_ID
from END_HLDG_HIST_T C, END_SEC_T S, END_CLS_CD_T CL
where C.sec_id = S.sec_id
and s.SEC_CLS_CD = CL.SEC_CLS_CD
group by C.KEMID, CL.SEC_RPT_GRP, C.HLDG_IP_IND, C.sec_id, C.regis_cd, C.ME_DT_ID
