create view END_KEMID_CRNT_BAL_DET_V as
select
B.kemid,
B.hldg_ip_ind,
(A.CRNT_INC_CSH + B.VAL_AT_MARKET) as VAL_AT_MARKET,
SEC_RPT_GRP,
ANN_INC_EST,
FY_REM_EST_INC,
NEXT_FY_EST_INC
from END_CRNT_CSH_T A
inner join
(
   select
   B.kemid,
   B.hldg_ip_ind,
   sum(B.HLDG_MVAL) as VAL_AT_MARKET,
   R.SEC_RPT_GRP as SEC_RPT_GRP,
   sum(HLDG_ANNL_INC_EST) as ANN_INC_EST,
   sum(HLDG_FY_REM_EST_INC) as FY_REM_EST_INC,
   sum(HLDG_NEXT_FY_EST_INC) as NEXT_FY_EST_INC
   from END_CRNT_TAX_LOT_BAL_T B, END_SEC_T S, END_CLS_CD_T CL, END_SEC_RPT_GRP_T R
   where S.SEC_ID = B.SEC_ID
   and S.SEC_CLS_CD = CL.SEC_CLS_CD
   and CL.SEC_RPT_GRP = R.SEC_RPT_GRP
   and CL.SEC_RPT_GRP = 'CSHEQ'
   and B.hldg_ip_ind = 'I'
   group by B.kemid, R.SEC_RPT_GRP, B.hldg_ip_ind
   order by kemid
)
B on B.kemid = A.kemid
union
select
B.kemid,
B.hldg_ip_ind,
(A.CRNT_PRIN_CSH + B.VAL_AT_MARKET) as VAL_AT_MARKET,
SEC_RPT_GRP,
ANN_INC_EST,
FY_REM_EST_INC,
NEXT_FY_EST_INC
from END_CRNT_CSH_T A
inner join
(
   select
   B.kemid,
   B.hldg_ip_ind,
   sum(B.HLDG_MVAL) as VAL_AT_MARKET,
   R.SEC_RPT_GRP as SEC_RPT_GRP,
   sum(HLDG_ANNL_INC_EST) as ANN_INC_EST,
   sum(HLDG_FY_REM_EST_INC) as FY_REM_EST_INC,
   sum(HLDG_NEXT_FY_EST_INC) as NEXT_FY_EST_INC
   from END_CRNT_TAX_LOT_BAL_T B, END_SEC_T S, END_CLS_CD_T CL, END_SEC_RPT_GRP_T R
   where S.SEC_ID = B.SEC_ID
   and S.SEC_CLS_CD = CL.SEC_CLS_CD
   and CL.SEC_RPT_GRP = R.SEC_RPT_GRP
   and CL.SEC_RPT_GRP = 'CSHEQ'
   and B.hldg_ip_ind = 'P'
   group by B.kemid, R.SEC_RPT_GRP, B.hldg_ip_ind
   order by kemid
)
B on B.kemid = A.kemid
union
select
B.kemid,
B.hldg_ip_ind,
sum(B.HLDG_MVAL) as VAL_AT_MARKET,
R.SEC_RPT_GRP,
sum(HLDG_ANNL_INC_EST) as ANN_INC_EST,
sum(HLDG_FY_REM_EST_INC) as FY_REM_EST_INC,
sum(HLDG_NEXT_FY_EST_INC) as NEXT_FY_EST_INC
from END_CRNT_TAX_LOT_BAL_T B,
END_CRNT_CSH_T C,
END_SEC_T S,
END_CLS_CD_T CL,
END_SEC_RPT_GRP_T R
where B.kemid= C.kemid
and S.SEC_ID = B.SEC_ID
and S.SEC_CLS_CD = CL.SEC_CLS_CD
and CL.SEC_RPT_GRP = R.SEC_RPT_GRP
and CL.SEC_RPT_GRP <> 'CSHEQ'
group by B.kemid, R.SEC_RPT_GRP, B.hldg_ip_ind
order by kemid
