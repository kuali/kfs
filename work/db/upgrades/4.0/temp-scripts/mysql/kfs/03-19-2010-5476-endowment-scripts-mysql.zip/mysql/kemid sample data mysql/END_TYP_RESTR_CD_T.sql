insert into END_TYP_RESTR_CD_T  (TYP_RESTR_CD, TYP_RESTR_DESC, PERM, ROW_ACTV_IND, OBJ_ID) values 
('AGY', 'Agency', 'N', 'Y',UUID()),
('NA', 'Not Applicable', 'N', 'Y',UUID()),
('NON', 'None Allowed', 'N', 'Y',UUID()),
('OBS', 'Off Balance Sheet', 'N', 'Y',UUID()),
('OP', 'Operations', 'N', 'Y',UUID()),
('PRF', 'Permanently Restricted - IUF', 'Y', 'Y',UUID()),
('PRU', 'Permanently Restricted - IU', 'Y', 'Y',UUID()),
('TRF', 'Temporarily Restricted - IUF', 'N', 'Y',UUID()),
('TRU', 'Temporarily Restricted - IU', 'N', 'Y',UUID());
