insert into END_FND_SRC_CD_T columns (FND_SRC_CD, FND_SRC_DESC, ROW_ACTV_IND, OBJ_ID) values ('MULT', 'Multiple Donors', 'Y',sys_guid());
insert into END_FND_SRC_CD_T columns (FND_SRC_CD, FND_SRC_DESC, ROW_ACTV_IND, OBJ_ID) values ('KEMID', 'Another KEMID', 'Y',sys_guid());
insert into END_FND_SRC_CD_T columns (FND_SRC_CD, FND_SRC_DESC, ROW_ACTV_IND, OBJ_ID) values ('DONOR', 'Specific Donor(s)', 'Y',sys_guid());
insert into END_FND_SRC_CD_T columns (FND_SRC_CD, FND_SRC_DESC, ROW_ACTV_IND, OBJ_ID) values ('POOL', 'Pooled Funds', 'Y',sys_guid());
insert into END_FND_SRC_CD_T columns (FND_SRC_CD, FND_SRC_DESC, ROW_ACTV_IND, OBJ_ID) values ('EARN', 'Earnings from another KEMID', 'Y',sys_guid());
