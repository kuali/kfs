insert into END_SEC_RPT_GRP_T (SEC_RPT_GRP, SEC_RPT_GRP_DESC, SEC_RPT_GRP_ORD, ROW_ACTV_IND, OBJ_ID) values 
('BND', 'Bonds', '2', 'Y',UUID()),
('STK', 'Stocks', '3', 'Y',UUID()),
('POOL', 'Pooled Funds', '4', 'Y',UUID()),
('Alt', 'Alternative Investments', '5', 'Y',UUID()),
('LIAB', 'Liabilities', '7', 'Y',UUID()),
('OTH', 'Other Assets', '6', 'Y',UUID());
