insert into END_SEC_RPT_GRP_T columns (SEC_RPT_GRP, SEC_RPT_GRP_DESC, SEC_RPT_GRP_ORD, ROW_ACTV_IND, OBJ_ID) values ('BND', 'Bonds', '2', 'Y',sys_guid());
insert into END_SEC_RPT_GRP_T columns (SEC_RPT_GRP, SEC_RPT_GRP_DESC, SEC_RPT_GRP_ORD, ROW_ACTV_IND, OBJ_ID) values ('STK', 'Stocks', '3', 'Y',sys_guid());
insert into END_SEC_RPT_GRP_T columns (SEC_RPT_GRP, SEC_RPT_GRP_DESC, SEC_RPT_GRP_ORD, ROW_ACTV_IND, OBJ_ID) values ('POOL', 'Pooled Funds', '4', 'Y',sys_guid());
insert into END_SEC_RPT_GRP_T columns (SEC_RPT_GRP, SEC_RPT_GRP_DESC, SEC_RPT_GRP_ORD, ROW_ACTV_IND, OBJ_ID) values ('ALT', 'Alternative Investments', '5', 'Y',sys_guid());
insert into END_SEC_RPT_GRP_T columns (SEC_RPT_GRP, SEC_RPT_GRP_DESC, SEC_RPT_GRP_ORD, ROW_ACTV_IND, OBJ_ID) values ('LIAB', 'Liabilities', '7', 'Y',sys_guid());
insert into END_SEC_RPT_GRP_T columns (SEC_RPT_GRP, SEC_RPT_GRP_DESC, SEC_RPT_GRP_ORD, ROW_ACTV_IND, OBJ_ID) values ('OTH', 'Other Assets', '6', 'Y',sys_guid());
