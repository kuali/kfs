insert into END_TRAN_RESTR_CD_T (TRAN_RESTR_CD, TRAN_RESTR_DESC, ROW_ACTV_IND, OBJ_ID) values 
('NDISB', 'No Disbursements', 'Y',UUID()),
('DEP', 'Deposits Only', 'Y',UUID()),
('NTRAN', 'No Transactions', 'Y',UUID()),
('ADMIN', 'Admin Approval Required', 'Y',UUID()),
('SIGN', 'Signature Card Needed', 'Y',UUID()),
('ATRAN', 'Authorized Transactions Only', 'Y',UUID()),
('NONE', 'None', 'Y',UUID());
