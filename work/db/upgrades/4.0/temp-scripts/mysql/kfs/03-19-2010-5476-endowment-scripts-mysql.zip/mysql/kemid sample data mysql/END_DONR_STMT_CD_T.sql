insert into END_DONR_STMT_CD_T (DONR_STMT_CD, DONR_STMT_DESC, ROW_ACTV_IND, OBJ_ID) values 
('T', 'Terminated', 'y',UUID()),
('Q', 'Qualifies', 'y',UUID()),
('N', 'None', 'y',UUID()),
('M', 'Mid-Level', 'y',UUID()),
('MID', 'Mid-Level - DR', 'y',UUID()),
('S', 'Standard', 'y',UUID()),
('ST', 'Standard', 'y',UUID()),
('STD', 'Standard - DR', 'y',UUID()),
('TER', 'Terminated - DR', 'y',UUID());
