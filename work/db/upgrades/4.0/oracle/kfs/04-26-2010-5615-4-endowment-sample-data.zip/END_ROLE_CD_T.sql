insert into END_ROLE_CD_T columns (ROLE_CD, ROLE_DESC, ROW_ACTV_IND, OBJ_ID) values ('1', 'Primary Manager', 'Y',sys_guid());
insert into END_ROLE_CD_T columns (ROLE_CD, ROLE_DESC, ROW_ACTV_IND, OBJ_ID) values ('2', 'Secondary Manager', 'Y',sys_guid());
insert into END_ROLE_CD_T columns (ROLE_CD, ROLE_DESC, ROW_ACTV_IND, OBJ_ID) values ('3', 'Primary Supervisor', 'Y',sys_guid());
insert into END_ROLE_CD_T columns (ROLE_CD, ROLE_DESC, ROW_ACTV_IND, OBJ_ID) values ('4', 'Secondary Supervisor', 'Y',sys_guid());
insert into END_ROLE_CD_T columns (ROLE_CD, ROLE_DESC, ROW_ACTV_IND, OBJ_ID) values ('5', 'Financial Management', 'Y',sys_guid());
insert into END_ROLE_CD_T columns (ROLE_CD, ROLE_DESC, ROW_ACTV_IND, OBJ_ID) values ('6', 'Development', 'Y',sys_guid());
