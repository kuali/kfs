insert into END_AGRMNT_SPCL_INSTRC_CD_T  (AGRMNT_SPCL_INSTRC_CD, AGRMNT_SPCL_INSTRC_DESC, ROW_ACTV_IND, OBJ_ID) values 
('RE', 'Reinvest earnings to specific fund balances', 'Y',UUID()),
('RP', 'Reinvest % of earnings', 'Y',UUID()),
('TP', 'Transfer % of earnings to separate account', 'Y',UUID()),
('TS', 'Transfer specific amount to separate account', 'Y',UUID()),
('OT', 'Other', 'Y',UUID()),
('RF', 'Reinvest unused FY earnings per GA', 'Y',UUID());
