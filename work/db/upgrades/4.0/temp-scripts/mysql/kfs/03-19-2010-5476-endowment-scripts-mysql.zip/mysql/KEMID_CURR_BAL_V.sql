create view END_KEMID_CRNT_BAL_V as
select
AUX1.kemid as KEMID,
AUX2.INCOME_AT_MARKET as INC_AT_MARKET,
AUX2.PRINCIPAL_AT_MARKET as PRIN_AT_MARKET,
AUX2.TOTAL_MARKET_VAL as TOTAL_MARKET_VAL,
AUX1.ANNUAL_INCOME as ANN_EST_INC,
AUX1.FY_REM_EST_INC as FY_REM_EST_INC,
AUX1.NEXT_FY_EST_INC as NEXT_FY_EST_INC
from ( select kemid, sum(HLDG_ANNL_INC_EST) as ANNUAL_INCOME, sum(HLDG_FY_REM_EST_INC) as FY_REM_EST_INC, sum(HLDG_NEXT_FY_EST_INC) as NEXT_FY_EST_INC from END_CRNT_TAX_LOT_BAL_T group by kemid ) AUX1,

(
   select
   TEMP1.*,
   TEMP2.INCOME_AT_MARKET,
   (INCOME_AT_MARKET + PRINCIPAL_AT_MARKET) as TOTAL_MARKET_VAL
   from
   (
      select
      A.kemid, (CRNT_PRIN_CSH + TOTAL_PRIN_MARKET_VAL) as PRINCIPAL_AT_MARKET
      from END_CRNT_CSH_T A
      inner join
      (
         select
         E.kemid, sum(hldg_mval) as TOTAL_PRIN_MARKET_VAL
         from END_CRNT_TAX_LOT_BAL_T E
         where E.hldg_IP_IND = 'P'
         group by E.kemid
      )
      B on B.kemid = A.kemid
   )
   TEMP1
   inner join
   (
      select
      A.KEMID, (CRNT_INC_CSH + TOTAL_INC_MARKET_VAL) as INCOME_AT_MARKET
      from END_CRNT_CSH_T A
      inner join
      (
         select
         E.kemid, sum(hldg_mval) as TOTAL_INC_MARKET_VAL
         from END_CRNT_TAX_LOT_BAL_T E
         where E.hldg_IP_IND = 'I'
         group by E.kemid
      )
      B on B.kemid = A.kemid
   )
   TEMP2 on TEMP1.kemid = TEMP2.kemid
)
AUX2
where aux1.kemid = aux2.kemid
