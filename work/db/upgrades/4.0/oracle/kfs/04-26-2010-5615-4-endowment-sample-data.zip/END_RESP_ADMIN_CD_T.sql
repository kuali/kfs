insert into END_RESP_ADMIN_CD_T columns (RESP_ADMIN_CD, RESP_ADMIN_DESC, ROW_ACTV_IND, OBJ_ID) values ('ACCT', 'Accounting', 'Y',sys_guid());
insert into END_RESP_ADMIN_CD_T columns (RESP_ADMIN_CD, RESP_ADMIN_DESC, ROW_ACTV_IND, OBJ_ID) values ('AGNC', 'Agency', 'Y',sys_guid());
insert into END_RESP_ADMIN_CD_T columns (RESP_ADMIN_CD, RESP_ADMIN_DESC, ROW_ACTV_IND, OBJ_ID) values ('GENA', 'General Administration', 'Y',sys_guid());
insert into END_RESP_ADMIN_CD_T columns (RESP_ADMIN_CD, RESP_ADMIN_DESC, ROW_ACTV_IND, OBJ_ID) values ('INTL', 'Internal', 'Y',sys_guid());
insert into END_RESP_ADMIN_CD_T columns (RESP_ADMIN_CD, RESP_ADMIN_DESC, ROW_ACTV_IND, OBJ_ID) values ('INVS', 'Investments', 'Y',sys_guid());
insert into END_RESP_ADMIN_CD_T columns (RESP_ADMIN_CD, RESP_ADMIN_DESC, ROW_ACTV_IND, OBJ_ID) values ('PLFD', 'Pooled Funds', 'Y',sys_guid());
insert into END_RESP_ADMIN_CD_T columns (RESP_ADMIN_CD, RESP_ADMIN_DESC, ROW_ACTV_IND, OBJ_ID) values ('TRST', 'Trust Accounting', 'Y',sys_guid());
