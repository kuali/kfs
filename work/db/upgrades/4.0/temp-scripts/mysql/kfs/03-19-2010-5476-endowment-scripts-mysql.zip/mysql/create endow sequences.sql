CREATE TABLE END_KEMID_SEQ
(
id bigint(19) not null auto_increment, primary key (id)
);

ALTER TABLE END_KEMID_SEQ auto_increment = 1;

CREATE TABLE END_TKLR_SEQ
(
id bigint(19) not null auto_increment, primary key (id)
)

ALTER TABLE END_TKLR_SEQ auto_increment = 1