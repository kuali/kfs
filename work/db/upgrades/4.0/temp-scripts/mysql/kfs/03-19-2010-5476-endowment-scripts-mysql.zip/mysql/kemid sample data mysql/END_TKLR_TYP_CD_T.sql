insert into END_TKLR_TYP_CD_T (TKLR_TYP_CD, TKLR_TYP_DESC, ROW_ACTV_IND, OBJ_ID) values 
('A', 'Asset Review', 'Y',UUID()),
('C', 'Compliance Review', 'Y',UUID()),
('D', 'Dormant Review', 'Y',UUID()),
('F', 'Funding Review', 'Y',UUID()),
('I', 'Income Review', 'Y',UUID()),
('M', 'Fiscal Management', 'Y',UUID()),
('Q', 'Special Request', 'Y',UUID()),
('R', 'Reinvestment Review', 'Y',UUID()),
('S', 'Signature Review', 'Y',UUID()),
('T', 'Trust Review', 'Y',UUID());
