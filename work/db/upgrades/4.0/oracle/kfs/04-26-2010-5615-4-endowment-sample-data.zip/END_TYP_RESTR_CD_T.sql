insert into END_TYP_RESTR_CD_T columns (TYP_RESTR_CD, TYP_RESTR_DESC, PERM, ROW_ACTV_IND, OBJ_ID) values ('AGY', 'Agency', 'N', 'Y',sys_guid());
insert into END_TYP_RESTR_CD_T columns (TYP_RESTR_CD, TYP_RESTR_DESC, PERM, ROW_ACTV_IND, OBJ_ID) values ('NA', 'Not Applicable', 'N', 'Y',sys_guid());
insert into END_TYP_RESTR_CD_T columns (TYP_RESTR_CD, TYP_RESTR_DESC, PERM, ROW_ACTV_IND, OBJ_ID) values ('NON', 'None Allowed', 'N', 'Y',sys_guid());
insert into END_TYP_RESTR_CD_T columns (TYP_RESTR_CD, TYP_RESTR_DESC, PERM, ROW_ACTV_IND, OBJ_ID) values ('OBS', 'Off Balance Sheet', 'N', 'Y',sys_guid());
insert into END_TYP_RESTR_CD_T columns (TYP_RESTR_CD, TYP_RESTR_DESC, PERM, ROW_ACTV_IND, OBJ_ID) values ('OP', 'Operations', 'N', 'Y',sys_guid());
insert into END_TYP_RESTR_CD_T columns (TYP_RESTR_CD, TYP_RESTR_DESC, PERM, ROW_ACTV_IND, OBJ_ID) values ('PRF', 'Permanently Restricted - IUF', 'Y', 'Y',sys_guid());
insert into END_TYP_RESTR_CD_T columns (TYP_RESTR_CD, TYP_RESTR_DESC, PERM, ROW_ACTV_IND, OBJ_ID) values ('PRU', 'Permanently Restricted - IU', 'Y', 'Y',sys_guid());
insert into END_TYP_RESTR_CD_T columns (TYP_RESTR_CD, TYP_RESTR_DESC, PERM, ROW_ACTV_IND, OBJ_ID) values ('TRF', 'Temporarily Restricted - IUF', 'N', 'Y',sys_guid());
insert into END_TYP_RESTR_CD_T columns (TYP_RESTR_CD, TYP_RESTR_DESC, PERM, ROW_ACTV_IND, OBJ_ID) values ('TRU', 'Temporarily Restricted - IU', 'N', 'Y',sys_guid());
