insert into END_AGRMNT_STAT_CD_T columns (AGRMNT_STAT_CD, AGRMNT_STAT_DESC, AGRMNT_DFLT_TRAN_RESTR, ROW_ACTV_IND, OBJ_ID) values ('COMP', 'Completed', 'NONE', 'Y',sys_guid());
insert into END_AGRMNT_STAT_CD_T columns (AGRMNT_STAT_CD, AGRMNT_STAT_DESC, AGRMNT_DFLT_TRAN_RESTR, ROW_ACTV_IND, OBJ_ID) values ('DRFT', 'Draft', 'NDISB', 'Y',sys_guid());
insert into END_AGRMNT_STAT_CD_T columns (AGRMNT_STAT_CD, AGRMNT_STAT_DESC, AGRMNT_DFLT_TRAN_RESTR, ROW_ACTV_IND, OBJ_ID) values ('NONE', 'Not Applicable', 'NONE', 'Y',sys_guid());
insert into END_AGRMNT_STAT_CD_T columns (AGRMNT_STAT_CD, AGRMNT_STAT_DESC, AGRMNT_DFLT_TRAN_RESTR, ROW_ACTV_IND, OBJ_ID) values ('PEND', 'Pending', 'NDISB', 'Y',sys_guid());
