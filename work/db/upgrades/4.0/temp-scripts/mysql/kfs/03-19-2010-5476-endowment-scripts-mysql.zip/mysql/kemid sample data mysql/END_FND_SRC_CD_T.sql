insert into END_FND_SRC_CD_T (FND_SRC_CD, FND_SRC_DESC, ROW_ACTV_IND, OBJ_ID) values 
('MULT', 'Multiple Donors', 'Y',UUID()),
('KEMID', 'Another KEMID', 'Y',UUID()),
('DONOR', 'Specific Donor(s)', 'Y',UUID()),
('POOL', 'Pooled Funds', 'Y',UUID()),
('EARN', 'Earnings from another KEMID', 'Y',UUID());
