insert into END_ROLE_CD_T (ROLE_CD, ROLE_DESC, ROW_ACTV_IND, OBJ_ID) values 
('1', 'Primary Manager', 'Y',UUID()),
('2', 'Secondary Manager', 'Y',UUID()),
('3', 'Primary Supervisor', 'Y',UUID()),
('4', 'Secondary Supervisor', 'Y',UUID()),
('5', 'Financial Management', 'Y',UUID()),
('6', 'Development', 'Y',UUID());
